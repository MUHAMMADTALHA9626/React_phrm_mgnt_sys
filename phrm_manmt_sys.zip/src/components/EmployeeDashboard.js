import React from 'react';
import { Link} from 'react-router-dom';

const EmployeeDashboard = () => {
  // Styles
  const containerStyle = {
    width: '80%',
    maxWidth: '600px',
    margin: '50px auto',
    marginTop: '11rem',
    padding: '20px',
    textAlign: 'center',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.5)',
    backgroundColor: 'white',
  };

  const headingStyle = {
    color: '#770000',
    fontWeight: 'bold',
    marginBottom: '30px',
    fontSize: '24px',
    textTransform: 'uppercase',
    letterSpacing: '1.5px',
  };

  const listStyle = {
    listStyleType: 'none',
    padding: '0',
    margin: '0',
  };

  const listItemStyle = {
    marginBottom: '15px',
  };

  const linkStyle = {
    display: 'block',
    padding: '15px 20px',
    textDecoration: 'none',
    backgroundColor: '#770000',
    color: 'white',
    borderRadius: '4px',
    fontWeight: 'bold',
    transition: 'background-color 0.3s ease',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
  };

  const linkHoverStyle = {
    backgroundColor: '#ff0000',
  };

  return (
    <div style={containerStyle}>
      <h2 style={headingStyle}>Employee Dashboard</h2>
      <ul style={listStyle}>
      <li style={listItemStyle}>
          <Link
            to="/stock"
            style={linkStyle}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = linkHoverStyle.backgroundColor)}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = linkStyle.backgroundColor)}
          >
            View Stock
          </Link>
        </li>
        <li style={listItemStyle}>
          <Link
            to="/products"
            style={linkStyle}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = linkHoverStyle.backgroundColor)}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = linkStyle.backgroundColor)}
          >
            View Products
          </Link>
        </li>
        <li style={listItemStyle}>
          <Link
            to="/logout"
            style={linkStyle}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = linkHoverStyle.backgroundColor)}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = linkStyle.backgroundColor)}
          >
            Logout
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default EmployeeDashboard;
