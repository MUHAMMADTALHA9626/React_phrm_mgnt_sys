import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import './Inventory.css';

const Inventory = () => {
  const [medicines, setMedicines] = useState([]);
  const [medTools, setMedTools] = useState([]);
  const [medicineInput, setMedicineInput] = useState({
    formula: '',
    brandName: '',
    medicineId: '',
    quantity: '',
  });
  const [medToolInput, setMedToolInput] = useState({
    toolName: '',
    quantity: '',
  });
  const [editIndex, setEditIndex] = useState(null);
  const [isEditingMedicine, setIsEditingMedicine] = useState(false);
  const [isEditingTool, setIsEditingTool] = useState(false);

  // Fetch and read Excel files when component mounts
  useEffect(() => {
    // Fetch Medicines Excel file
    fetch('../public/excel/Medicines.xlsx')
      .then((response) => response.arrayBuffer())
      .then((data) => {
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        setMedicines(jsonData);
      })
      .catch((error) => console.error('Error fetching Medicines file:', error));

    // Fetch Medical Tools Excel file
    fetch('../public/excel/MedTools.xlsx')
      .then((response) => response.arrayBuffer())
      .then((data) => {
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        setMedTools(jsonData);
      })
      .catch((error) => console.error('Error fetching MedTools file:', error));
  }, []);

  // Handle input changes for medicines
  const handleMedicineInputChange = (e) => {
    const { name, value } = e.target;
    setMedicineInput({ ...medicineInput, [name]: value });
  };

  // Handle input changes for med tools
  const handleMedToolInputChange = (e) => {
    const { name, value } = e.target;
    setMedToolInput({ ...medToolInput, [name]: value });
  };

  // Add or update medicine
  const handleMedicineSubmit = (e) => {
    e.preventDefault();
    if (isEditingMedicine) {
      const updatedMedicines = [...medicines];
      updatedMedicines[editIndex] = medicineInput;
      setMedicines(updatedMedicines);
      setIsEditingMedicine(false);
      setEditIndex(null);
    } else {
      setMedicines([...medicines, medicineInput]);
    }
    setMedicineInput({
      formula: '',
      brandName: '',
      medicineId: '',
      quantity: '',
    });
  };

  // Add or update med tool
  const handleMedToolSubmit = (e) => {
    e.preventDefault();
    if (isEditingTool) {
      const updatedMedTools = [...medTools];
      updatedMedTools[editIndex] = medToolInput;
      setMedTools(updatedMedTools);
      setIsEditingTool(false);
      setEditIndex(null);
    } else {
      setMedTools([...medTools, medToolInput]);
    }
    setMedToolInput({
      toolName: '',
      quantity: '',
    });
  };

  // Edit medicine
  const editMedicine = (index) => {
    setMedicineInput(medicines[index]);
    setIsEditingMedicine(true);
    setEditIndex(index);
  };

  // Edit med tool
  const editMedTool = (index) => {
    setMedToolInput(medTools[index]);
    setIsEditingTool(true);
    setEditIndex(index);
  };

  // Delete medicine
  const deleteMedicine = (index) => {
    const updatedMedicines = medicines.filter((_, i) => i !== index);
    setMedicines(updatedMedicines);
  };

  // Delete med tool
  const deleteMedTool = (index) => {
    const updatedMedTools = medTools.filter((_, i) => i !== index);
    setMedTools(updatedMedTools);
  };

  return (
    <div className="inventory-container">
      <h2>Inventory Management</h2>
      <hr className="divider" />

      {/* Medicine Form */}
      <form onSubmit={handleMedicineSubmit} className="form-section">
        <h3>Manage Medicines</h3>
        <input
          type="text"
          name="formula"
          placeholder="Formula"
          value={medicineInput.formula}
          onChange={handleMedicineInputChange}
          required
        />
        <input
          type="text"
          name="brandName"
          placeholder="Brand Name"
          value={medicineInput.brandName}
          onChange={handleMedicineInputChange}
          required
        />
        <input
          type="text"
          name="medicineId"
          placeholder="Medicine ID"
          value={medicineInput.medicineId}
          onChange={handleMedicineInputChange}
          required
        />
        <input
          type="number"
          name="quantity"
          placeholder="Quantity"
          value={medicineInput.quantity}
          onChange={handleMedicineInputChange}
          required
        />
        <button type="submit">{isEditingMedicine ? 'Update Medicine' : 'Add'}</button>
      </form>

      {/* Medicine List */}
      <h3>Medicines List</h3>
        <ul className="medicine-list">
          {medicines.map((medicine, index) => (
            <li key={index}>
              {medicine.formula} - {medicine.brandName} (ID: {medicine.medicineId}) - Qty: {medicine.quantity}
              <button onClick={() => editMedicine(index)}>Edit</button>
              <button onClick={() => deleteMedicine(index)}>Delete</button>
            </li>
          ))}
        </ul>

      {/* Med Tool Form */}
      <form onSubmit={handleMedToolSubmit} className="form-section">
        <h3>Manage Medical Tools</h3>
        <input
          type="text"
          name="toolName"
          placeholder="Tool Name"
          value={medToolInput.toolName}
          onChange={handleMedToolInputChange}
          required
        />
        <input
          type="number"
          name="quantity"
          placeholder="Quantity"
          value={medToolInput.quantity}
          onChange={handleMedToolInputChange}
          required
        />
        <button type="submit">{isEditingTool ? 'Update Tool' : 'Add'}</button>
      </form>

          </div>
  );
};

export default Inventory;