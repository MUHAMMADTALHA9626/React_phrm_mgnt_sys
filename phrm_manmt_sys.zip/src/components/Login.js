import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [role, setRole] = useState('employee');
  const [id, setId] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    if (role === 'admin') {
      navigate('/admin-dashboard');
    } else {
      navigate('/employee-dashboard');
    }
  };

  const homePage = () => {
    navigate('/');
    };

  // Styles
  const containerStyle = {
    width: '700px',
    height: '400px',
    margin: '100px auto',
    padding: '50px',
    backgroundColor: 'white',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.5)',
  };

  const inputStyle = {
    
    display: 'block',
    width: '100%',
    marginBottom: '10px',
    padding: '8px',
    fontSize: '18px',
    border: '1px solid #ccc',
    borderRadius: '3px',
    boxSizing: 'border-box',
  };

  const buttonStyle = {
    display: 'block',
    fontSize: '18px',
    width: '100%',
    padding: '8px',
    backgroundColor: '#770000',
    color: 'white',
    border: 'none',
    borderRadius: '3px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
    marginBottom: '10px',
  };

  const buttonStyle1 = {
    display: 'block',
    fontSize: '18px',
    width: '100%',
    padding: '8px',
    backgroundColor: 'rgb(15, 0, 99)',
    color: 'white',
    border: 'none',
    borderRadius: '3px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
    marginBottom: '10px',
  };

  const buttonHoverStyle = {
    backgroundColor: '#ff0000',
  };

  const buttonHoverStyle1 = {
    backgroundColor: 'rgb(40, 2, 255)',
  };

  return (
    <div className="login-container" style={containerStyle}>
      <h2 style={{ color: 'black', textAlign: 'center', fontWeight: 'bold', fontSize: '30px'}}>The Pharma</h2>
      <select style={inputStyle} onChange={(e) => setRole(e.target.value)} value={role}>
        <option value="employee">Employee</option>
        <option value="admin">Admin</option>
      </select>
      <input
        type="text"
        placeholder="Enter ID"
        value={id}
        onChange={(e) => setId(e.target.value)}
        style={inputStyle}
      />
      <button
        style={buttonStyle}
        onMouseEnter={(e) => (e.target.style.backgroundColor = buttonHoverStyle.backgroundColor)}
        onMouseLeave={(e) => (e.target.style.backgroundColor = buttonStyle.backgroundColor)}
        onClick={handleLogin}
      >
        Login
      </button>
      <button
        style={buttonStyle1}
        onMouseEnter={(e) => (e.target.style.backgroundColor = buttonHoverStyle1.backgroundColor)}
        onMouseLeave={(e) => (e.target.style.backgroundColor = buttonStyle1.backgroundColor)}
        onClick={homePage}
      >
        Home Page
      </button>
    </div>
  );
};

export default Login;
