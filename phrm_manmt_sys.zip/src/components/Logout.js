import React from 'react';
import { useNavigate } from 'react-router-dom';

const Logout = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate('/login');
  };

  // Styles
  const containerStyle = {
    width: '700px',
    height: '300px',
    margin: '100px auto',
    padding: '50px',
    backgroundColor: 'white',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.5)',
    textAlign: 'center',
    marginTop: '10rem',
  };

  const buttonStyle = {
    display: 'inline-block',
    fontSize: '18px',
    width: '100%',
    padding: '10px',
    backgroundColor: '#770000',
    color: 'white',
    border: 'none',
    borderRadius: '3px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
    marginBottom: '10px',
  };

  const buttonHoverStyle = {
    backgroundColor: '#ff0000',
  };

  return (
    <div style={containerStyle}>
      <h2 style={{ color: 'black', fontWeight: 'bold', fontSize: '30px' }}>Click to Logout</h2>
      <button
        style={buttonStyle}
        onMouseEnter={(e) => (e.target.style.backgroundColor = buttonHoverStyle.backgroundColor)}
        onMouseLeave={(e) => (e.target.style.backgroundColor = buttonStyle.backgroundColor)}
        onClick={handleLogout}
      >
        Logout
      </button>
    </div>
  );
};

export default Logout;
