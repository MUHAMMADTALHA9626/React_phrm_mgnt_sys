import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';

const ProductList = () => {
  const [medProducts, setMedProducts] = useState([]);
  const [medToolsProducts, setMedToolsProducts] = useState([]);
  const [currentView, setCurrentView] = useState(null); // New state variable to track the current view

  useEffect(() => {
    const fetchAndParseFiles = async () => {
      const fileUrls = [
        { url: '/excel/Medicines.xlsx', setter: setMedProducts, heading: 'Meds' },
        { url: '/excel/MedTools.xlsx', setter: setMedToolsProducts, heading: 'MedTools Products' },
      ];

      for (const { url, setter } of fileUrls) {
        try {
          // Fetch file
          const response = await fetch(url);
          const data = await response.arrayBuffer();

          // Parse file
          const workbook = XLSX.read(data, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          const sheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(sheet);
          setter(jsonData); // Set the data for each sheet
        } catch (error) {
          console.error(`Error fetching or parsing file ${url}:`, error);
        }
      }
    };

    fetchAndParseFiles();
  }, []);

  // Styling
  const tableStyle = {
    width: '80%',
    margin: '20px auto',
    borderCollapse: 'collapse',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  };

  const headerStyle = {
    backgroundColor: '#770000',
    color: 'white',
    padding: '10px',
    fontWeight: 'bold',
  };

  const cellStyle = {
    border: '1px solid #ccc',
    padding: '10px',
    textAlign: 'left',
  };

  const baseBtnStyle = {
    padding: '10px 20px',
    fontSize: '16px',
    width: '100%',
    backgroundColor: 'white',
    color: 'black',
    borderRadius: '10px',
    border: '1px solid black', 
    cursor: 'pointer',
  };

  const activeBtnStyle = {
    backgroundColor: '#770000',
    color: 'white',
  };

  const renderTable = (data, heading) => (
    <div style={{ marginBottom: '40px' }}>
      <h3>{heading}</h3>
      <table style={tableStyle}>
        <thead>
          <tr>
            {Object.keys(data[0] || {}).map((key) => (
              <th key={key} style={headerStyle}>{key}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => (
            <tr key={index}>
              {Object.values(item).map((value, idx) => (
                <td key={idx} style={cellStyle}>{value}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  return (
    <div>
      <h2 style={{ textAlign: 'center', fontSize: '30px' }}>Product List</h2>
      <hr style={{ border: '1px solid #770000', marginBottom: '20px' }} />
      <div style={{ display: 'flex', justifyContent: 'center', gap: '5rem' }}>
        <div style={{ display: 'flex', width: '50%', justifyContent: 'center', alignItems: 'center' }}>
          <button 
            style={currentView === 'Medicines' ? {...baseBtnStyle, ...activeBtnStyle} : baseBtnStyle}
            // ? and : are conditional statements.  === matches the exact element.  ... is a spread operator provides the overall data
            onClick={() => setCurrentView('Medicines')}
          >
            Medicines
          </button>
        </div>

        <div style={{ display: 'flex', width: '50%', justifyContent: 'center', alignItems: 'center' }}>
          <button 
            style={currentView === 'Tools' ? {...baseBtnStyle, ...activeBtnStyle} : baseBtnStyle}
            onClick={() => setCurrentView('Tools')}
          >
            Tools
          </button>
        </div>
      </div>
      {currentView === 'Medicines' && renderTable(medProducts)}
      {currentView === 'Tools' && renderTable(medToolsProducts)}
    </div>
  );
};

export default ProductList;
