import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';

const Stock = () => {
  const [medProducts, setMedProducts] = useState([]);
  const [medToolsProducts, setMedToolsProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentView, setCurrentView] = useState(null);

  useEffect(() => {
    const fetchAndParseFiles = async () => {
      const fileUrls = [
        { url: '/excel/Medicines.xlsx', setter: setMedProducts, heading: 'Meds' },
        { url: '/excel/MedTools.xlsx', setter: setMedToolsProducts, heading: 'MedTools Products' },
      ];

      for (const { url, setter } of fileUrls) {
        try {
          const response = await fetch(url);
          const data = await response.arrayBuffer();
          const workbook = XLSX.read(data, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          const sheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(sheet);
          setter(jsonData);
        } catch (error) {
          console.error(`Error fetching or parsing file ${url}:`, error);
        }
      }
    };

    fetchAndParseFiles();
  }, []);

  const filterData = (data) => data.filter((item) => item.Quantity > 0);

  const handleSearch = (data) => {
    if (!searchTerm) return data;
    const lowerCaseSearchTerm = searchTerm.toLowerCase();
    return data.filter((item) =>
      Object.values(item).some(
        (value) => value && value.toString().toLowerCase().includes(lowerCaseSearchTerm)
      )
    );
  };

  const tableStyle = {
    width: '80%',
    margin: '20px auto',
    borderCollapse: 'collapse',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
  };

  const headerStyle = {
    backgroundColor: '#770000',
    color: 'white',
    padding: '10px',
    fontWeight: 'bold',
  };

  const cellStyle = {
    border: '1px solid #ccc',
    padding: '10px',
    textAlign: 'left',
  };

  const baseBtnStyle = {
    padding: '10px 20px',
    fontSize: '16px',
    width: '100%',
    backgroundColor: 'white',
    color: 'black',
    borderRadius: '10px',
    border: '1px solid black', 
    cursor: 'pointer',
  };

  const activeBtnStyle = {
    backgroundColor: '#770000',
    color: 'white',
  };

  const renderTable = (data, heading) => {
    const filteredData = filterData(data);
    const searchedData = handleSearch(filteredData);

    return (
      <div style={{ marginBottom: '40px' }}>
        <h3>{heading}</h3>
        <table style={tableStyle}>
          <thead>
            <tr>
              {Object.keys(searchedData[0] || {}).map((key) => (
                <th key={key} style={headerStyle}>{key}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {searchedData.map((item, index) => (
              <tr key={index}>
                {Object.values(item).map((value, idx) => (
                  <td key={idx} style={cellStyle}>{value}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div>
      <h2 style={{ textAlign: 'center', fontSize: '30px'}}>Stocks</h2>
      <hr style={{ border: '1px solid #770000', marginBottom: '20px'}} />
      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <input
          type="text"
          placeholder="Search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{ padding: '10px', width: '300px', borderRadius: '4px', border: '1px solid #ccc' }}
        />
      </div>
      <div style={{ display: 'flex', justifyContent: 'center', gap: '5rem', marginBottom: '20px' }}>
        <div style={{ display: 'flex', width: '50%', justifyContent: 'center', alignItems: 'center' }}>
          <button 
            style={currentView === 'Medicines' ? {...baseBtnStyle, ...activeBtnStyle} : baseBtnStyle}
            onClick={() => setCurrentView('Medicines')}
          >
            Medicines
          </button>
        </div>

        <div style={{ display: 'flex', width: '50%', justifyContent: 'center', alignItems: 'center' }}>
          <button 
            style={currentView === 'Tools' ? {...baseBtnStyle, ...activeBtnStyle} : baseBtnStyle}
            onClick={() => setCurrentView('Tools')}
          >
            Tools
          </button>
        </div>
      </div>
      {currentView === 'Medicines' && renderTable(medProducts, 'Med Products')}
      {currentView === 'Tools' && renderTable(medToolsProducts, 'Tools')}
    </div>
  );
};

export default Stock;