import React from 'react';
import { Link } from 'react-router-dom';
import './HomePage.css';

const HomePage = () => {
  const images = [
    "https://entsupplies.com/wp-content/uploads/2016/05/Fotolia_86737698_Subscription_Monthly_XXL-2048x1365.jpg",
    "http://www.dubaistandard.com/wp-content/uploads/2017/03/medicine-tablets.jpg",
    "https://vegasvalleyvein.com/wp-content/uploads/2018/11/medical_equipment.jpg",
    "https://uoflhealth.org/wp-content/uploads/2021/11/First-Aid-kit.jpg",
    "http://www.shsu.edu/academics/health-sciences/image/HealthSciences_Hero3.jpg"
  ];

  return (
    <div className="homepage-container">
      <h1>Welcome to The Pharma</h1>
      <p>Manage your pharmacy efficiently with our user-friendly interface.</p>

      <div className="homepage-navigation">
        <Link to="/login">
          <button className="login-button">Get Started</button>
        </Link>
      </div>

      <div className="container">
        {images.map((src, index) => (
          <img
            key={index}
            src={src}
            alt={`Pharmacy related content ${index + 1}`}
            className="img"
          />
        ))}
      </div>
    </div>
  );
};

export default HomePage;
